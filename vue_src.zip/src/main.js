import Vue from "vue";
import App from "./App.vue";
import router from "./router";
import store from "./store";

// 集成外部的模块 到 vue 中, 有两种做法:
// 1.简单粗暴, 操作原型: Vue.prototype.xxx = xxx;
// 2.官方推荐, 优雅: Vue.use()
import "./vendor/axios";

Vue.config.productionTip = false;

new Vue({
  router,
  store,
  render: (h) => h(App),
}).$mount("#app");
