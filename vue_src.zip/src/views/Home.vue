<template>
  <div>
    <h1>学生列表</h1>
    <!-- table>tr*2>td*6 -->
    <table border="1" align="center">
      <tr>
        <td>序号</td>
        <td>姓名</td>
        <td>年龄</td>
        <td>性别</td>
        <td>手机号</td>
        <td>邮箱</td>
        <td>操作</td>
      </tr>
      <tr v-for="(item, index) in res" :key="index">
        <td>{{ index + 1 }}</td>
        <td>{{ item.name }}</td>
        <td>
          <button @click="updateAge(index, -1)">-</button>
          <span>{{ item.age }}</span>
          <button @click="updateAge(index, +1)">+</button>
        </td>
        <td>{{ item.gender | gender }}</td>
        <td>{{ item.phone }}</td>
        <td>{{ item.email }}</td>
        <td><button @click="doDel(index)">删除</button></td>
      </tr>
    </table>
  </div>
</template>

<script>
export default {
  // data属性中的数据可以在 模板中使用
  data() {
    return {
      res: [],
    };
  },
  // 生命周期: 挂载
  mounted() {
    this.getData();
  },
  // 书写函数
  methods: {
    updateAge(index, delta) {
      // index: 序号
      // delta: +1 或 -1
      const { id, age } = this.res[index];
      const url = `http://localhost:8000/stu_update_age?id=${id}&age=${age +
        delta}`;

      this.axios.get(url).then((res) => {
        console.log(res);
        // 实时更新本地数据
        if (res.data.code == 200) {
          this.res[index].age = age + delta;
        }
      });
    },
    doDel(index) {
      //删除 指定序号对应的数据
      const id = this.res[index].id;

      const url = "http://localhost:8000/stu_del?id=" + id;

      this.axios.get(url).then((res) => {
        console.log(res);
        if (res.data.code == 200) {
          // 成功后, 删除本地数据
          this.res.splice(index, 1);
        }
      });
    },

    getData() {
      // django服务器 制作的接口
      const url = "http://127.0.0.1:8000/students";

      this.axios.get(url).then((res) => {
        console.log(res);
        this.res = res.data.res;
      });
    },
  },
  // 过滤器: 专门调节 {{}} 中的值
  filters: {
    gender(value) {
      // if (value == 0) return "女";
      // if (value == 1) return "男";
      // if (value == 2) return "保密";
      return ["女", "男", "保密"][value];
      // 某些选项通常赋值 0 1 2 ... 为了搭配数组使用
    },
  },
};
</script>

<style></style>
