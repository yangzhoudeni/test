<template>
  <div>
    <h1>新增学员</h1>
    <table border="1" align="center">
      <tr>
        <td>姓名</td>
        <td><input type="text" v-model="name" /></td>
      </tr>
      <tr>
        <td>性别</td>
        <td align="left">
          <select v-model="gender">
            <option value="0">女</option>
            <option value="1">男</option>
            <option value="2">保密</option>
          </select>
        </td>
      </tr>
      <tr>
        <td>年龄</td>
        <td><input type="text" v-model="age" /></td>
      </tr>
      <tr>
        <td>手机号</td>
        <td><input type="text" v-model="phone" /></td>
      </tr>
      <tr>
        <td>邮箱</td>
        <td><input type="text" v-model="email" /></td>
      </tr>
      <tr>
        <td></td>
        <td><button style="width:100%" @click="doAdd">添加</button></td>
      </tr>
    </table>
  </div>
</template>

<script>
import qs from "qs";

export default {
  // vue双向绑定: 1.数据变化时,UI同步更新  2.界面发生变化时,同步修改数据
  data() {
    return {
      name: "",
      age: 0,
      gender: 1,
      email: "",
      phone: "",
    };
  },
  methods: {
    doAdd() {
      console.log(this.name, this.age, this.gender, this.email, this.phone);

      // POST请求
      const url = "http://localhost:8000/stu_add";
      // 拼接 url 参数串比较麻烦, 系统提供了 qs 库, 专门帮助实现 url 拼接
      // 先写 object 格式, 然后转URL格式
      let params = {
        name: this.name,
        age: this.age,
        gender: this.gender,
        email: this.email,
        phone: this.phone,
      };

      params = qs.stringify(params);
      console.log(params);

      this.axios.post(url, params).then((res) => {
        console.log(res);
      });
    },
  },
};
</script>

<style></style>
