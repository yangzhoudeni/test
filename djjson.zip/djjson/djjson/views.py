# JsonResponse: 负责把 数组/字典 类型, 转化成 JSON格式的字符串 进行反馈
from django.http import HttpResponse, JsonResponse
from django.http.request import HttpRequest
from mysql.connector import connect

# 接口: 网页发送请求, 获取数据库的数据.  中间需要服务器进行数据的传递


def students(req):
    # 查询所有学生
    link = connect(database='web2010', user='root', passwd="")

    sql = 'SELECT * FROM student'
    cur = link.cursor(dictionary=True)
    cur.execute(sql)

    res = cur.fetchall()

    return JsonResponse({"res": res})


def index(req):
    # 字典 or 数组 类型, 都需要转为 字符串 才能返回
    data = {
        'title': 'Hello World!',
        'name': '东东',
        'skills': ['vue', 'vuex', 'json', 'elementUI', 'mintUI', 'echarts']
    }

    # return HttpResponse('<h1>Hello World</h1>')
    # 推荐使用 火狐 浏览器, 自带json格式化工具
    return JsonResponse(data)


def stu_del(req: HttpRequest):
    # req: 其中存储了请求相关的值, 例如传参
    # 当前接口: stu_del?id=xxx
    # 参数用?方式传输:  属于 GET 请求
    id = req.GET.get('id')

    link = connect(user='root', passwd="", database="web2010")
    sql = 'DELETE FROM student WHERE id=%s'
    args = (id,)

    cur = link.cursor()
    cur.execute(sql, args)
    row = cur.rowcount
    link.commit()
    # 根据删除的行数 来决定是否成功
    return JsonResponse({
        # 自定义code值, 200代表成功 201代表失败;  -- 把code含义写到文档中 提供给前端人员使用
        "code": 200 if row == 1 else 201,
        # msg: 给不愿意看文档的前端人员一个 容易理解的结果提示
        'msg': 'del suc' if row == 1 else 'del failed'
    })


def stu_update_age(req: HttpRequest):
    id = req.GET.get('id')
    age = req.GET.get('age')

    # 容错处理: 经验告诉我们: 前端人员在使用服务器接口时, 最常见的问题: 参数传输错误!
    if id == None:
        # 设定:202代表参数错误
        return JsonResponse({'code': 202, "msg": '参数id未传递!'})

    if age == None:
        # 设定:202代表参数错误
        return JsonResponse({'code': 202, "msg": '参数age未传递!'})

    link = connect(database="web2010", user='root', passwd="")
    sql = 'UPDATE student SET age=%s WHERE id=%s'
    args = (age, id)

    cur = link.cursor()
    cur.execute(sql, args)

    row = cur.rowcount

    link.commit()

    return JsonResponse({
        'code': 200 if row == 1 else 201,
        'msg': 'update suc' if row == 1 else 'update fail'
    })


def stu_add(req: HttpRequest):
    # 增操作: 参数数量很多. 参数数量较多时, 服务器通常采用 POST 方式传参
    # 参数: name age gender email phone
    name = req.POST.get('name')
    age = req.POST.get('age')
    gender = req.POST.get('gender')
    email = req.POST.get('email')
    phone = req.POST.get('phone')

    if name == None:
        return JsonResponse({'code': 202, 'msg': 'name required!'})
    if age == None:
        return JsonResponse({'code': 202, 'msg': 'age required!'})
    if gender == None:
        return JsonResponse({'code': 202, 'msg': 'gender required!'})
    if email == None:
        return JsonResponse({'code': 202, 'msg': 'email required!'})
    if phone == None:
        return JsonResponse({'code': 202, 'msg': 'phone required!'})

    link = connect(database='web2010', user='root', passwd="")
    sql = 'INSERT INTO student(name,age,gender,email,phone) VALUES(%s,%s,%s,%s,%s)'

    cur = link.cursor()
    cur.execute(sql, (name, age, gender, email, phone))

    row = cur.rowcount
    link.commit()

    return JsonResponse({
        'code': 200 if row == 1 else 201,
        'msg': 'insert suc' if row == 1 else 'insert failed'
    })
