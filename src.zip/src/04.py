# 改
from mysql.connector import connect


link = connect(database='web2010', user='root', passwd="")

name = '然然的裹脚布'

sql = 'UPDATE product SET name=%s WHERE price > 6000 and price < 8000'

# 参数就算只有一个, 也必须是元组类型. 且元组类型至少一个逗号
link.cursor().execute(sql, (name,))

link.commit()
