# 创建商品表
from mysql.connector import connect

link = connect(user='root', passwd="", database="web2010")

print(link)

sql = '''
CREATE TABLE IF NOT EXISTS product(
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL COMMENT '名称',
    price DECIMAL(12,2) NOT NULL COMMENT '单价',
    count INT NOT NULL COMMENT '数量',
    phone CHAR(11) NOT NULL UNIQUE COMMENT '手机号',
    email VARCHAR(255) NOT NULL UNIQUE COMMENT '邮箱',
    address VARCHAR(255) NOT NULL COMMENT '地址'
) CHARSET=utf8
'''

link.cursor().execute(sql)
