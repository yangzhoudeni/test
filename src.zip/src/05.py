# 查

from mysql.connector import connect

link = connect(database='web2010', user='root', passwd="")

sql = 'SELECT * FROM product'

cur = link.cursor(dictionary=True)
cur.execute(sql)

res = cur.fetchall()

print(res)
