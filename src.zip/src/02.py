# 增
import random
from mysql.connector import connect
from random import randint

link = connect(user='root', passwd="", database='web2010')

sql = 'INSERT INTO product(name,price,count,phone,email,address) VALUES(%s,%s,%s,%s,%s,%s)'

name = 'iPhone%s' % randint(4, 30)
price = '%s.%s' % (randint(4e3, 2e4), randint(10, 99))
count = randint(0, 100)
phone = '188%s' % randint(1e7, 9e7)
email = '%s@qq.com' % randint(1e5, 9e10)
address = '北京市%s区%s路%s街%s号' % (randint(1, 100), randint(
    1, 100), randint(1, 100), randint(1, 100))

args = (name, price, count, phone, email, address)

link.cursor().execute(sql, args)
# 增删改:都会变动数据, 必须二次确认
link.commit()
