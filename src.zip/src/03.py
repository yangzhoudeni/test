# 删除

from mysql.connector import connect

link = connect(database='web2010', user='root', passwd="")

sql = 'DELETE FROM product WHERE price < 6000'

cur = link.cursor()
cur.execute(sql)

row = cur.rowcount

print('删除了%s行' % row)

link.commit()  # 删除操作, 影响数据, 必须二次提交
