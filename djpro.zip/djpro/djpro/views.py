# 自建文件: 名称随意 但是习惯上写 views.py
from django.http import HttpResponse


def index(req):
    # req: 必带参数, 其中存放了 请求相关的信息, 例如参数.
    # HttpResponse: 用于反馈文本信息的类
    return HttpResponse('<h1>Hello World!!!!!</h1>')


def news(req):
    return HttpResponse('<h1>新闻页面</h1>')


def product(req):
    return HttpResponse('<h1>产品页面</h1>')
